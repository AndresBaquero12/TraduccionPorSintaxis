import sys
import time
from typing import Dict, List, Tuple, Optional

# CLASES BÁSICAS
class Token:
    def __init__(self, tipo: str, lexema: str, linea: int, columna: int, valor=None):
        self.tipo = tipo
        self.lexema = lexema
        self.linea = linea
        self.columna = columna
        self.valor = valor

    def __repr__(self):
        return f"Token({self.tipo}, '{self.lexema}', {self.linea}, {self.columna})"

class ErrorSintactico(Exception):
    def __init__(self, token, esperados=None):
        self.token = token
        self.esperados = esperados or []
    
    def __str__(self):
        texto_token = "$" if self.token.tipo == "EOF" else self.token.lexema
        esperados_str = ", ".join(f'"{e}"' for e in self.esperados)
        return f'<{self.token.linea},{self.token.columna}> Error sintáctico: se encontró: "{texto_token}"; se esperaba: {esperados_str}'

class NodoAST:
    """Nodo del Árbol de Sintaxis Abstracta"""
    def __init__(self, tipo: str, valor=None):
        self.tipo = tipo
        self.valor = valor
        self.hijos: List['NodoAST'] = []
        self.atributos = {}
        
    def agregar_hijo(self, hijo: 'NodoAST'):
        self.hijos.append(hijo)
    
    def establecer_atributo(self, nombre: str, valor):
        self.atributos[nombre] = valor
    
    def obtener_atributo(self, nombre: str):
        return self.atributos.get(nombre)
# TABLA DE SÍMBOLOS

class EntradaTabla:
    def __init__(self, nombre: str, tipo: str, valor=None, linea: int = 0):
        self.nombre = nombre
        self.tipo = tipo
        self.valor = valor
        self.linea = linea

class TablaSimbolos:
    def __init__(self):
        self.simbolos: Dict[str, EntradaTabla] = {}
    
    def agregar(self, nombre: str, tipo: str, valor=None, linea: int = 0) -> bool:
        if nombre in self.simbolos:
            return False
        self.simbolos[nombre] = EntradaTabla(nombre, tipo, valor, linea)
        return True
    
    def existe(self, nombre: str) -> bool:
        return nombre in self.simbolos
    
    def obtener(self, nombre: str) -> Optional[EntradaTabla]:
        return self.simbolos.get(nombre)

# ANALIZADOR LÉXICO
SIMBOLOS = {
    "(": "PAR_IZQ",
    ")": "PAR_DER",
    "+": "MAS",
    "-": "MENOS",
    "*": "POR",
    "/": "DIV",
}

class AnalizadorLexico:
    def __init__(self, codigo: str):
        self.codigo = codigo
        self.pos = 0
        self.linea = 1
        self.columna = 1
        self.tokens: List[Token] = []
        self._tokenizar()
    
    def _avanzar_caracter(self):
        if self.pos < len(self.codigo):
            char = self.codigo[self.pos]
            self.pos += 1
            if char == '\n':
                self.linea += 1
                self.columna = 1
            else:
                self.columna += 1
            return char
        return None
    
    def _mirar_siguiente(self):
        if self.pos < len(self.codigo):
            return self.codigo[self.pos]
        return None
    
    def _tokenizar(self):
        while self.pos < len(self.codigo):
            char = self._mirar_siguiente()
            
            if char in " \t\n\r":
                self._avanzar_caracter()
                continue
            
            if char in SIMBOLOS:
                inicio_col = self.columna
                self._avanzar_caracter()
                self.tokens.append(Token(SIMBOLOS[char], char, self.linea, inicio_col))
                continue
            
            if char.isdigit():
                inicio_col = self.columna
                numero = ""
                tiene_punto = False
                while char and (char.isdigit() or (char == '.' and not tiene_punto)):
                    if char == '.':
                        tiene_punto = True
                    numero += self._avanzar_caracter()
                    char = self._mirar_siguiente()
                valor = float(numero) if tiene_punto else int(numero)
                self.tokens.append(Token("NUMERO", numero, self.linea, inicio_col, valor))
                continue
            
            if char.isalpha() or char == '_':
                inicio_col = self.columna
                identificador = ""
                while char and (char.isalnum() or char == '_'):
                    identificador += self._avanzar_caracter()
                    char = self._mirar_siguiente()
                self.tokens.append(Token("IDENTIFICADOR", identificador, self.linea, inicio_col))
                continue
            
            inicio_col = self.columna
            self._avanzar_caracter()
            self.tokens.append(Token("DESCONOCIDO", char, self.linea, inicio_col))
        
        self.tokens.append(Token("EOF", "$", self.linea, self.columna))

# ANALIZADOR SINTÁCTICO

class ParserLL1:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0
        self.actual: Token = None
        self.tabla_simbolos = TablaSimbolos()
        self._avanzar()
    
    def _avanzar(self):
        if self.pos < len(self.tokens):
            self.actual = self.tokens[self.pos]
            self.pos += 1
    
    def _comer(self, tipo: str) -> Token:
        if self.actual.tipo == tipo:
            token_actual = self.actual
            self._avanzar()
            return token_actual
        else:
            raise ErrorSintactico(self.actual, [tipo])
    
    def analizar(self) -> NodoAST:
        ast = self._expresion()
        self._comer("EOF")
        return ast
    
    def _expresion(self) -> NodoAST:
        nodo_t = self._termino()
        nodo_e = self._expresion_prima(nodo_t)
        return nodo_e
    
    def _expresion_prima(self, heredado: NodoAST) -> NodoAST:
        if self.actual.tipo in ["MAS", "MENOS"]:
            operador = self.actual.lexema
            self._avanzar()
            nodo_t = self._termino()
            nodo_op = NodoAST("OPERACION", operador)
            nodo_op.agregar_hijo(heredado)
            nodo_op.agregar_hijo(nodo_t)
            return self._expresion_prima(nodo_op)
        else:
            return heredado
    
    def _termino(self) -> NodoAST:
        nodo_f = self._factor()
        nodo_t = self._termino_prima(nodo_f)
        return nodo_t
    
    def _termino_prima(self, heredado: NodoAST) -> NodoAST:
        if self.actual.tipo in ["POR", "DIV"]:
            operador = self.actual.lexema
            self._avanzar()
            nodo_f = self._factor()
            nodo_op = NodoAST("OPERACION", operador)
            nodo_op.agregar_hijo(heredado)
            nodo_op.agregar_hijo(nodo_f)
            return self._termino_prima(nodo_op)
        else:
            return heredado
    
    def _factor(self) -> NodoAST:
        if self.actual.tipo == "PAR_IZQ":
            self._comer("PAR_IZQ")
            nodo_e = self._expresion()
            self._comer("PAR_DER")
            return nodo_e
        elif self.actual.tipo == "NUMERO":
            token = self._comer("NUMERO")
            nodo = NodoAST("NUMERO", token.valor)
            return nodo
        elif self.actual.tipo == "IDENTIFICADOR":
            token = self._comer("IDENTIFICADOR")
            if not self.tabla_simbolos.existe(token.lexema):
                self.tabla_simbolos.agregar(token.lexema, "variable", None, token.linea)
            nodo = NodoAST("IDENTIFICADOR", token.lexema)
            return nodo
        elif self.actual.tipo in ["MAS", "MENOS"]:
            operador = self.actual.lexema
            self._avanzar()
            nodo_f = self._factor()
            nodo_unario = NodoAST("UNARIO", operador)
            nodo_unario.agregar_hijo(nodo_f)
            return nodo_unario
        else:
            raise ErrorSintactico(self.actual, ["NUMERO", "IDENTIFICADOR", "PAR_IZQ", "MAS", "MENOS"])

# DECORADOR DE AST

class DecoradorAST:
    def __init__(self, tabla_simbolos: TablaSimbolos):
        self.tabla_simbolos = tabla_simbolos
    
    def decorar(self, nodo: NodoAST) -> float:
        if nodo.tipo == "NUMERO":
            valor = float(nodo.valor)
            nodo.establecer_atributo("val", valor)
            return valor
        elif nodo.tipo == "IDENTIFICADOR":
            entrada = self.tabla_simbolos.obtener(nodo.valor)
            valor = entrada.valor if entrada and entrada.valor is not None else 0
            nodo.establecer_atributo("val", valor)
            return valor
        elif nodo.tipo == "OPERACION":
            izq = self.decorar(nodo.hijos[0])
            der = self.decorar(nodo.hijos[1])
            operador = nodo.valor
            if operador == '+':
                resultado = izq + der
            elif operador == '-':
                resultado = izq - der
            elif operador == '*':
                resultado = izq * der
            elif operador == '/':
                resultado = izq / der if der != 0 else float('inf')
            else:
                resultado = 0
            nodo.establecer_atributo("val", resultado)
            return resultado
        elif nodo.tipo == "UNARIO":
            valor_hijo = self.decorar(nodo.hijos[0])
            resultado = +valor_hijo if nodo.valor == '+' else -valor_hijo
            nodo.establecer_atributo("val", resultado)
            return resultado
        return 0

class GeneradorCodigoIntermedio:
    def __init__(self):
        self.codigo: List[str] = []
        self.contador_temp = 0
        self.evaluaciones: List[Tuple[str, float]] = []  # Para mostrar resultados parciales
    
    def _nuevo_temporal(self) -> str:
        temp = f"t{self.contador_temp}"
        self.contador_temp += 1
        return temp
    
    def generar(self, nodo: NodoAST) -> str:
        if nodo.tipo == "NUMERO":
            return f"{nodo.valor}"
        elif nodo.tipo == "IDENTIFICADOR":
            return nodo.valor
        elif nodo.tipo == "OPERACION":
            izq = self.generar(nodo.hijos[0])
            der = self.generar(nodo.hijos[1])
            temp = self._nuevo_temporal()
            instruccion = f"{temp} = {izq} {nodo.valor} {der}"
            self.codigo.append(instruccion)
            # Guardar resultado parcial
            resultado_parcial = nodo.obtener_atributo("val")
            self.evaluaciones.append((instruccion, resultado_parcial))
            return temp
        elif nodo.tipo == "UNARIO":
            operando = self.generar(nodo.hijos[0])
            temp = self._nuevo_temporal()
            instruccion = f"{temp} = {nodo.valor}{operando}"
            self.codigo.append(instruccion)
            resultado_parcial = nodo.obtener_atributo("val")
            self.evaluaciones.append((instruccion, resultado_parcial))
            return temp
        return ""


class VisualizadorSimple:
    @staticmethod
    def imprimir_arbol_simple(nodo: NodoAST, prefijo: str = "", es_ultimo: bool = True) -> List[str]:
        lineas = []
        conector = "└─ " if es_ultimo else "├─ "
        
        if nodo.tipo == "OPERACION":
            simbolo = {"+" : "Suma (+)", "-": "Resta (-)", "*": "Multiplicación (*)", "/": "División (/)"}
            info = simbolo.get(nodo.valor, nodo.valor)
        elif nodo.tipo == "UNARIO":
            info = f"Operador unario ({nodo.valor})"
        elif nodo.tipo == "NUMERO":
            info = f"Número: {nodo.valor}"
        elif nodo.tipo == "IDENTIFICADOR":
            info = f"Variable: {nodo.valor}"
        else:
            info = nodo.tipo
        
        lineas.append(prefijo + conector + info)
        
        if nodo.hijos:
            extension = "   " if es_ultimo else "│  "
            nuevo_prefijo = prefijo + extension
            for i, hijo in enumerate(nodo.hijos):
                es_ultimo_hijo = (i == len(nodo.hijos) - 1)
                lineas.extend(VisualizadorSimple.imprimir_arbol_simple(hijo, nuevo_prefijo, es_ultimo_hijo))
        
        return lineas

def analizar_expresion_simple(expresion: str) -> str:
    """Análisis con salida simplificada - Modo Resumen Ejecutivo"""
    
    resultado = []
    tiempo_inicio = time.time()

    resultado.append("  ANALIZADOR DE EXPRESIONES ARITMÉTICAS     ")
    resultado.append("")
    resultado.append(f"📝 Expresión: {expresion}")
    resultado.append("")
    
    try:
        # Análisis léxico
        lexer = AnalizadorLexico(expresion)
        errores_lexicos = [t for t in lexer.tokens if t.tipo == "DESCONOCIDO"]
        
        if errores_lexicos:
            resultado.append("❌ ERROR LÉXICO")
            resultado.append("")
            for error in errores_lexicos:
                resultado.append(f"   Carácter inválido '{error.lexema}' en línea {error.linea}, columna {error.columna}")
            return '\n'.join(resultado)
        
        # Obtener tokens legibles
        tokens_texto = []
        for token in lexer.tokens:
            if token.tipo == "NUMERO":
                tokens_texto.append(str(token.valor))
            elif token.tipo != "EOF":
                tokens_texto.append(token.lexema)
        
        # Análisis sintáctico
        parser = ParserLL1(lexer.tokens)
        ast = parser.analizar()
        
        # Análisis semántico
        decorador = DecoradorAST(parser.tabla_simbolos)
        valor_final = decorador.decorar(ast)
        
        # Generación de código
        generador = GeneradorCodigoIntermedio()
        resultado_var = generador.generar(ast)
        
        # SALIDA EXITOSA
        resultado.append("✅ ANÁLISIS EXITOSO")
        resultado.append("")
        resultado.append("📊 Resumen:")
        resultado.append(f"   • Resultado: {valor_final}")
        resultado.append(f"   • Tokens encontrados: {len(lexer.tokens) - 1} ({', '.join(tokens_texto)})")
        resultado.append(f"   • Variables usadas: {len(parser.tabla_simbolos.simbolos)}")
        
        if parser.tabla_simbolos.simbolos:
            vars_lista = [f"{s}" for s in parser.tabla_simbolos.simbolos.keys()]
            resultado.append(f"     └→ {', '.join(vars_lista)}")
        
        resultado.append(f"   • Instrucciones generadas: {len(generador.codigo)}")
        resultado.append("")
        
        # Código generado con resultados parciales
        if generador.codigo:
            resultado.append("💻 Código generado:")
            for i, (instruccion, valor_parcial) in enumerate(generador.evaluaciones, 1):
                if valor_parcial is not None:
                    resultado.append(f"   {i}. {instruccion:<20} → resultado parcial: {valor_parcial}")
                else:
                    resultado.append(f"   {i}. {instruccion}")
            resultado.append("")
        
        # Árbol de operaciones
        resultado.append("🌳 Árbol de operaciones:")
        lineas_arbol = VisualizadorSimple.imprimir_arbol_simple(ast)
        for linea in lineas_arbol:
            resultado.append("   " + linea)
        resultado.append("")
        
        # Explicación paso a paso
        if generador.codigo:
            resultado.append("💡 Explicación:")
            for i, (instruccion, valor) in enumerate(generador.evaluaciones, 1):
                # Parsear la instrucción para explicarla
                partes = instruccion.split('=')
                if len(partes) == 2:
                    temp_var = partes[0].strip()
                    operacion = partes[1].strip()
                    
                    if i < len(generador.evaluaciones):
                        resultado.append(f"   Paso {i}: {operacion} = {valor}")
                    else:
                        resultado.append(f"   Paso {i}: {operacion} = {valor}")
            
            resultado.append(f"   Resultado final: {valor_final}")
        else:
            resultado.append("💡 Explicación:")
            resultado.append(f"   Expresión simple: el resultado es {valor_final}")
        
        resultado.append("")
        
    except ErrorSintactico as e:
        resultado.append("❌ ERROR SINTÁCTICO")
        resultado.append("")
        resultado.append(f"   {e}")
        return '\n'.join(resultado)
    
    except Exception as e:
        resultado.append("❌ ERROR INESPERADO")
        resultado.append("")
        resultado.append(f"   {e}")
        return '\n'.join(resultado)
    
    # Tiempo de ejecución
    tiempo_fin = time.time()
    tiempo_total = tiempo_fin - tiempo_inicio
    resultado.append(f"⏱️  Tiempo: {tiempo_total:.4f} segundos")
    resultado.append("")
    resultado.append("═" * 63)
    
    return '\n'.join(resultado)


def main():
    if len(sys.argv) != 2:
        print("ANALIZADOR DE EXPRESIONES ARITMÉTICAS")
        print("Esquema de Traducción Dirigida por Sintaxis (ETDS)")
        print("\nUso:")
        print("  python Gramatica.py <archivo.txt>")
        print("\nEjemplo:")
        print("  python Gramatica.py Prueba.txt\n")
        sys.exit(1)

    archivo = sys.argv[1]

    try:
        with open(archivo, 'r', encoding='utf-8') as f:
            contenido = f.read().strip()

        if not contenido:
            print(f"❌ Error: El archivo '{archivo}' está vacío")
            sys.exit(1)

        print(f"\n📂 Leyendo expresiones desde: {archivo}\n")

        expresiones = [linea.strip() for linea in contenido.split('\n') if linea.strip()]
        todos_resultados = []

        for i, expresion in enumerate(expresiones, 1):
            # Eliminado: impresión de líneas gruesas y encabezado de expresión
            resultado = analizar_expresion_simple(expresion)
            print(resultado)
            todos_resultados.append(resultado)

        nombre_salida = archivo.replace('.txt', '_output.txt')
        with open(nombre_salida, "w", encoding="utf-8") as f:
            f.write('\n\n'.join(todos_resultados))

        print(f"\nResultados guardados en: {nombre_salida}")
        print(f"Total de expresiones procesadas: {len(expresiones)}\n")

    except FileNotFoundError:
        print(f"❌ Error: No se encontró el archivo '{archivo}'")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error inesperado: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()